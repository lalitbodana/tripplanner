package com.fakecoders.tripplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
